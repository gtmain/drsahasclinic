/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { 
  Phone, 
  MapPin, 
  Clock, 
  Star, 
  ChevronRight, 
  CheckCircle2, 
  Calendar,
  MessageSquare,
  Award,
  Users,
  ShieldCheck,
  Stethoscope,
  HeartPulse,
  Brain,
  Menu,
  X,
  Droplets,
  Activity,
  ArrowRight
} from 'lucide-react';
import { useState, useEffect } from 'react';

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-sm py-3' : 'bg-transparent py-5'}`}>
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-clinic-primary rounded-lg flex items-center justify-center">
            <HeartPulse className="text-white w-5 h-5" />
          </div>
          <div>
            <span className="text-xl font-extrabold text-clinic-secondary tracking-tight">DR SAHA’S <span className="text-clinic-accent-green">CLINIC</span></span>
          </div>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          <a href="#about" className="text-sm font-semibold text-clinic-text hover:text-clinic-primary transition-colors">About</a>
          <a href="#treatments" className="text-sm font-semibold text-clinic-text hover:text-clinic-primary transition-colors">Treatments</a>
          <a href="#why-us" className="text-sm font-semibold text-clinic-text hover:text-clinic-primary transition-colors">Why us</a>
          <a href="#contact" className="text-sm font-semibold text-clinic-text hover:text-clinic-primary transition-colors">Contact</a>
          <div className="flex gap-3">
             <a href="tel:09609935326" className="border-2 border-clinic-primary text-clinic-primary px-5 py-2 rounded-xl text-sm font-bold hover:bg-blue-50 transition-all">Call Now</a>
             <a href="tel:09609935326" className="bg-clinic-primary text-white px-5 py-2 rounded-xl text-sm font-bold hover:bg-clinic-secondary transition-all">Book Online</a>
          </div>
        </div>

        {/* Mobile Toggle */}
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="md:hidden p-2 text-slate-700 focus:outline-none">
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-white border-t border-slate-100 absolute top-full left-0 right-0 shadow-xl overflow-hidden"
        >
          <div className="flex flex-col p-6 gap-4">
            <a href="#about" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-medium">About</a>
            <a href="#treatments" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-medium">Treatments</a>
            <a href="#why-us" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-medium">Why Us</a>
            <a href="#contact" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-medium">Contact</a>
            <hr className="border-slate-100" />
            <a href="tel:09609935326" className="bg-clinic-primary text-white py-4 rounded-xl flex items-center justify-center gap-2 text-lg font-bold">
              <Phone className="w-5 h-5" />
              Call Now
            </a>
          </div>
        </motion.div>
      )}
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-gradient-to-br from-clinic-hero-start to-clinic-hero-end">
      {/* Abstract Background Shapes */}
      <div className="absolute top-20 right-[-10%] w-[500px] h-[500px] bg-blue-300/20 rounded-full blur-3xl -z-10" />

      <div className="container mx-auto px-4 md:px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="stat-badge-minimal mb-6">
              <div className="flex text-amber-400">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-current" />)}
              </div>
              <span className="text-xs font-bold">4.9 Rating (700+ Reviews)</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-extrabold text-clinic-secondary leading-[1.1] mb-6">
              Trusted Homeopathy<br />Care in Gangarampur
            </h1>
            
            <p className="text-lg text-clinic-muted mb-8 max-w-lg leading-relaxed">
              Natural healing focused on root-cause diagnosis and long-term wellness for you and your family.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <a href="tel:09609935326" className="btn-primary-minimal text-center">
                Get Appointment
              </a>
              <a href="#treatments" className="btn-outline-minimal border-slate-200 text-slate-600 bg-white hover:bg-slate-50 flex items-center justify-center gap-2">
                Watch Clinic Tour
                <ChevronRight className="w-5 h-5" />
              </a>
            </div>

            <div className="mt-12 flex items-center gap-6">
               <div className="flex -space-x-3">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-white overflow-hidden bg-slate-200">
                      <img src={`https://picsum.photos/seed/doctor${i}/100/100`} alt="Patient" referrerPolicy="no-referrer" />
                    </div>
                  ))}
               </div>
               <p className="text-sm text-slate-500">
                 Join <strong>700+ happy patients</strong> who recovered naturally.
               </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative"
          >
            <div className="relative aspect-[4/5] rounded-[40px] overflow-hidden shadow-2xl">
              <img 
                src="https://picsum.photos/seed/healthcare/1200/1500" 
                alt="Dr Saha's Clinic" 
                className="object-cover w-full h-full"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-clinic-secondary/40 to-transparent" />
            </div>
            
            {/* Floating Info Cards */}
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -bottom-6 -left-6 bg-white p-5 rounded-3xl shadow-xl border border-slate-100 flex items-center gap-4 hidden lg:flex"
            >
              <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center">
                 <CheckCircle2 className="text-clinic-accent-green" />
              </div>
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Treatment</p>
                <p className="text-sm font-bold text-slate-800">100% Side-effect free</p>
              </div>
            </motion.div>
            
            <motion.div 
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              className="absolute -top-6 -right-6 bg-white p-5 rounded-3xl shadow-xl border border-slate-100 flex items-center gap-4 hidden lg:flex"
            >
              <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center">
                 <Users className="text-clinic-primary" />
              </div>
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Experience</p>
                <p className="text-sm font-bold text-slate-800">15+ Years Excellence</p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const TrustSection = () => {
  const reviews = [
    { name: "Suman Mondal", text: "Accurate diagnosis and effective treatment. I was suffering from chronic back pain for years, and homeopathy finally gave me relief.", rating: 5 },
    { name: "Priya Roy", text: "Very friendly doctor and caring staff. The clinic is very clean and well-maintained. Highly recommended for family healthcare.", rating: 5 },
    { name: "Anita Das", text: "Relief from chronic problems like piles and headache. The medicines work slowly but address the root cause unlike others.", rating: 5 },
    { name: "Rahul Sharma", text: "Best homeopathy clinic in Gangarampur. Dr. Saha listens patiently and explains everything clearly. Very satisfied.", rating: 4.9 },
  ];

  return (
    <section className="py-24 bg-clinic-bg">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <span className="pill-minimal">Patient Satisfaction</span>
          <h2 className="text-4xl font-extrabold text-clinic-secondary mt-4 mb-6">Real Results, Real Sentiments</h2>
          <div className="flex justify-center items-center gap-2 mb-2">
            {[...Array(5)].map((_, i) => <Star key={i} className="text-amber-400 w-6 h-6 fill-current" />)}
            <span className="text-2xl font-bold ml-2">4.9/5</span>
          </div>
          <p className="text-clinic-muted">Based on 700+ Google & Local reviews</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {reviews.map((review, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -8 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="clinical-card flex flex-col h-full"
            >
              <div className="flex gap-1 text-amber-400 mb-4">
                {[...Array(5)].map((_, j) => <Star key={j} className="w-4 h-4 fill-current" />)}
              </div>
              <p className="italic text-clinic-text mb-8 flex-grow leading-relaxed">"{review.text}"</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-clinic-primary font-bold">
                  {review.name[0]}
                </div>
                <div>
                  <h4 className="font-bold text-sm">{review.name}</h4>
                  <p className="text-[10px] uppercase tracking-wider text-clinic-muted font-bold">Patient</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const AboutDoctor = () => {
  return (
    <section id="about" className="py-24 bg-white border-y border-clinic-border">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative aspect-square rounded-[40px] overflow-hidden shadow-xl border-8 border-white"
            >
               <img src="https://picsum.photos/seed/doctor-profile/800/800" alt="Dr Partha Pratim Saha" className="object-cover w-full h-full" referrerPolicy="no-referrer" />
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="absolute -bottom-6 -right-6 bg-clinic-secondary p-8 rounded-[30px] text-white shadow-xl max-w-xs"
            >
               <Award className="w-10 h-10 mb-4 text-clinic-accent-green" />
               <h3 className="text-xl font-bold mb-2">Homeopathy Specialist</h3>
               <p className="text-white/80 text-xs">Dedicated to natural healing through personalized treatment plans.</p>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="pill-minimal">Meet the Doctor</span>
            <h2 className="text-4xl font-extrabold text-clinic-secondary mt-4 mb-8">Dr. Partha Pratim Saha</h2>
            
            <div className="space-y-6 text-clinic-muted leading-relaxed text-lg">
              <p>
                With years of trusted clinical practice, Dr Saha has established himself as a leading Homeopathy Specialist in Gangarampur, known for his patient-first approach.
              </p>
              <p>
                He believes that effective healing starts with an <strong>attentive listener</strong>. By understanding the complete physical and mental state of his patients, he designs treatments that target the root cause of chronic ailments rather than just suppressing symptoms.
              </p>
              
              <div className="grid grid-cols-2 gap-4 mt-8">
                 {[ "Personalized Care", "Advanced Diagnosis", "Natural Healing", "Ethical Practice" ].map((item, idx) => (
                   <div key={idx} className="flex items-center gap-3">
                     <CheckCircle2 className="text-clinic-accent-green w-5 h-5 shrink-0" />
                     <span className="font-bold text-clinic-text text-sm">{item}</span>
                   </div>
                 ))}
              </div>

              <div className="pt-8">
                <a href="#contact" className="btn-outline-minimal inline-flex items-center gap-2">
                  Contact Now for Consultation
                  <ArrowRight className="w-5 h-5" />
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Treatments = () => {
  const treatments = [
    { title: "Chronic Pain", desc: "Back, joint, ankle & Sciatica relief", initial: "P" },
    { title: "Piles", desc: "Non-surgical effective treatment", initial: "PL" },
    { title: "Headache / Migraine", desc: "Long-term relief from chronic head pain", initial: "H" },
    { title: "Kidney Stones", desc: "Natural removal without surgery", initial: "K" },
    { title: "Skin & Hair", desc: "Alopecia, fungal infections, acne", initial: "S" },
    { title: "Hormonal Issues", desc: "Menstrual problems, prolactin, thyroid", initial: "HR" },
    { title: "Digestive Issues", desc: "Gas, acidity, IBS, constipation", initial: "D" },
    { title: "General Care", desc: "Whole-family wellness and immunity", initial: "G" },
  ];

  return (
    <section id="treatments" className="py-24 bg-clinic-bg">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-20 max-w-2xl mx-auto">
          <span className="pill-minimal">Specialized Treatments</span>
          <h2 className="text-4xl font-extrabold text-clinic-secondary mt-4 mb-6">Our Specializations</h2>
          <p className="text-clinic-muted text-lg">Flexible natural healthcare solutions for acute and chronic conditions.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {treatments.map((t, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -5 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="clinical-card clinical-shadow-hover"
            >
              <div className="w-10 h-10 bg-emerald-50 rounded-lg flex items-center justify-center text-clinic-accent-green font-bold text-sm mb-6">
                {t.initial}
              </div>
              <h3 className="text-lg font-bold text-clinic-secondary mb-2">{t.title}</h3>
              <p className="text-clinic-muted text-sm leading-relaxed">{t.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const WhyChooseUs = () => {
  const points = [
    { title: "Accurate Diagnosis", desc: "We spend time understanding your case to pinpoint the exact root cause." },
    { title: "Effective Medicines", desc: "High-quality homeopathic medicines with proven results in thousands." },
    { title: "Clean & Hygienic", desc: "A sanitized, comfortable, and well-decorated clinic environment." },
    { title: "Friendly Staff", desc: "Respectful and caring staff dedicated to your comfort during visits." },
    { title: "Personal Attention", desc: "You are not just another serial number. Personalized care for everyone." },
    { title: "Deep Listening", desc: "The doctor takes the time to listen to your history and concerns." },
  ];

  return (
    <section id="why-us" className="py-24 bg-clinic-secondary text-white overflow-hidden relative">
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <motion.div
             initial={{ opacity: 0, x: -30 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
          >
            <span className="pill-minimal text-slate-400">Why Dr Saha?</span>
            <h2 className="text-4xl font-extrabold mt-4 mb-10 leading-tight">Setting the Standard for Natural Medicine</h2>
            
            <div className="grid sm:grid-cols-2 gap-8">
               {points.map((p, i) => (
                 <div key={i} className="flex gap-4">
                   <div className="mt-1"><CheckCircle2 className="text-clinic-accent-green w-5 h-5 shrink-0" /></div>
                   <div>
                     <h4 className="font-bold text-lg mb-1">{p.title}</h4>
                     <p className="text-white/60 text-sm leading-relaxed">{p.desc}</p>
                   </div>
                 </div>
               ))}
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
             <div className="bg-white/10 backdrop-blur-lg p-3 rounded-[50px] rotate-3 relative z-20 overflow-hidden">
                <img src="https://picsum.photos/seed/healing-safe/800/600" alt="Clinic Interior" className="rounded-[40px] w-full" referrerPolicy="no-referrer" />
             </div>
             <div className="absolute inset-0 bg-blue-500/10 rounded-[50px] -rotate-3 z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const CTASection = () => {
  return (
    <section className="py-24 bg-clinic-bg">
      <div className="container mx-auto px-4 md:px-6 text-center">
         <motion.div 
           initial={{ opacity: 0, y: 30 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           className="bg-gradient-to-r from-clinic-hero-start to-clinic-hero-end p-12 md:p-20 rounded-[40px] border border-blue-100"
         >
            <h2 className="text-4xl md:text-5xl font-extrabold text-clinic-secondary mb-8 max-w-3xl mx-auto">Start Your Healing Journey Today</h2>
            <p className="text-xl text-clinic-muted mb-12 max-w-xl mx-auto">
              Natural relief is just a call away. Join the 700+ patients who chose natural recovery.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
               <a href="tel:09609935326" className="btn-primary-minimal text-xl flex items-center justify-center gap-3">
                  <Phone />
                  096099 35326
               </a>
               <a href="#contact" className="btn-outline-minimal border-white bg-white/50 text-clinic-secondary text-xl flex items-center justify-center gap-3">
                  <MapPin />
                  Visit Clinic
               </a>
            </div>
         </motion.div>
      </div>
    </section>
  );
};

const FAQ = () => {
  const faqs = [
    { q: "Is Homeopathy safe?", a: "Yes, homeopathy is 100% natural and safe when prescribed by a professional. It has no side effects and is suitable for all ages, including infants and pregnant women." },
    { q: "How long does the treatment take?", a: "The duration depends on the nature of the ailment. Acute conditions see quick relief, while chronic issues may take a few months to address the root cause for long-term results." },
    { q: "Do you treat chronic diseases?", a: "Dr Saha's Clinic specializes in chronic diseases like piles, skin disorders, chronic pain, and hormonal imbalances with high success rates." },
    { q: "Is accurate diagnosis guaranteed?", a: "We place high emphasis on complete case-taking and advanced diagnosis techniques to identify the core cause of your illness." },
  ];

  const [open, setOpen] = useState(0);

  return (
    <section className="py-24 bg-clinic-bg border-y border-clinic-border">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <span className="pill-minimal">Help & Support</span>
            <h2 className="text-4xl font-extrabold text-clinic-secondary mt-4 mb-8">Frequently Asked Questions</h2>
            <p className="text-clinic-muted mb-8 max-w-sm">We believe in transparent healthcare. If you have more questions, feel free to call our clinic.</p>
          </div>
          
          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <div 
                key={i} 
                className={`p-6 rounded-2xl border transition-all cursor-pointer ${open === i ? 'bg-white border-clinic-primary/20 shadow-md' : 'bg-white border-slate-200 hover:border-clinic-primary/10'}`}
                onClick={() => setOpen(i)}
              >
                <div className="flex justify-between items-center gap-4">
                  <h3 className="font-bold text-lg text-clinic-secondary">{faq.q}</h3>
                  <div className={`transition-transform duration-300 ${open === i ? 'rotate-180' : ''}`}>
                    <ChevronRight className="w-5 h-5 text-clinic-primary" />
                  </div>
                </div>
                {open === i && (
                  <motion.p 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="mt-4 text-clinic-muted leading-relaxed overflow-hidden"
                  >
                    {faq.a}
                  </motion.p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section id="contact" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid lg:grid-cols-3 gap-12">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-2"
          >
            <div className="w-full h-full min-h-[500px] rounded-[40px] overflow-hidden shadow-sm border border-clinic-border grayscale hover:grayscale-0 transition-all duration-700">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d230569.999066013!2d88.32279084616935!3d25.449753989019467!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fb470933ba7863%3A0xd48ef96a1f12b4d8!2sDr%20Saha's%20Clinic!5e0!3m2!1sen!2sin!4v1776694610032!5m2!1sen!2sin" 
                width="100%" 
                height="100%" 
                style={{ border: 0, minHeight: '500px' }} 
                allowFullScreen 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </motion.div>

          <div className="space-y-8">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="pill-minimal">Reach Us</span>
              <h2 className="text-4xl font-extrabold text-clinic-secondary mt-4 mb-8">Contact Information</h2>
            </motion.div>

            {[
              { icon: <MapPin />, title: "Clinic Address", text: "Duttapara Road, Gangarampur, West Bengal" },
              { icon: <Phone />, title: "Phone Number", text: "096099 35326", sub: "Tap to Call Now", link: "tel:09609935326" },
              { icon: <Clock />, title: "Clinic Timings", list: true }
            ].map((item, i) => (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex gap-6 items-start"
              >
                <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center shrink-0">
                  <span className="text-clinic-primary">{item.icon}</span>
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-1 text-clinic-secondary">{item.title}</h4>
                  {!item.list ? (
                    <>
                      <p className={`text-clinic-muted ${item.link ? 'font-bold text-xl text-clinic-primary' : ''}`}>{item.text}</p>
                      {item.link && <a href={item.link} className="text-clinic-primary text-sm font-bold hover:underline">{item.sub}</a>}
                    </>
                  ) : (
                    <div className="space-y-1 text-clinic-muted">
                      <div className="flex justify-between gap-8">
                        <span>Monday</span>
                        <span className="font-bold text-clinic-secondary">8 AM – 8:30 PM</span>
                      </div>
                      <div className="flex justify-between gap-8">
                        <span>Other Days</span>
                        <span className="text-slate-300 italic">Closed</span>
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="pt-6"
            >
               <a href="tel:09609935326" className="btn-primary-minimal w-full flex items-center justify-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  Connect With Us
               </a>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-clinic-secondary text-white pt-20 pb-10">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-20">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-8">
              <div className="w-10 h-10 bg-clinic-primary rounded-lg flex items-center justify-center">
                <HeartPulse className="text-white w-6 h-6" />
              </div>
              <div className="text-xl font-extrabold tracking-tight">DR. SAHA'S <span className="text-clinic-accent-green">CLINIC</span></div>
            </div>
            <p className="text-white/60 max-w-sm leading-relaxed mb-8">
              Providing natural and effective homeopathy treatments in Gangarampur. We believe in holistic healing that addresses the root cause of ailments.
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-8 text-lg text-white">Quick Links</h4>
            <ul className="space-y-4 text-white/70">
              <li><a href="#" className="hover:text-clinic-primary transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-clinic-primary transition-colors">About Doctor</a></li>
              <li><a href="#treatments" className="hover:text-clinic-primary transition-colors">Treatments</a></li>
              <li><a href="#contact" className="hover:text-clinic-primary transition-colors">Contact Us</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-8 text-lg text-white">Visit Us</h4>
            <ul className="space-y-4 text-white/70 text-sm">
              <li className="flex gap-2"><MapPin className="w-4 h-4 shrink-0 text-white/50" /> Duttapara Road, Gangarampur</li>
              <li className="flex gap-2 font-bold text-white"><Phone className="w-4 h-4 shrink-0 text-white/50" /> 096099 35326</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/10 pt-10 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-white/40 text-sm">© 2024 Dr Saha's Clinic. All rights reserved.</p>
          <div className="flex items-center gap-2 text-white/40 text-sm">
             Natural Healing Focused on You
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- Main App ---

export default function App() {
  return (
    <div className="relative selection:bg-clinic-primary selection:text-white">
      <Navbar />
      <main>
        <Hero />
        <TrustSection />
        <AboutDoctor />
        <Treatments />
        <WhyChooseUs />
        <CTASection />
        <FAQ />
        <Contact />
      </main>
      <Footer />
      
      {/* Mobile Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-40 md:hidden">
        <a href="tel:09609935326" className="w-16 h-16 bg-clinic-primary text-white rounded-full flex items-center justify-center shadow-2xl">
          <Phone className="w-6 h-6" />
        </a>
      </div>
    </div>
  );
}
